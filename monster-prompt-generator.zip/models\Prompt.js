const mongoose = require('mongoose');

const PromptSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  content: {
    type: String,
    required: [true, 'Prompt content is required'],
    trim: true
  },
  category: {
    type: String,
    enum: ['image-generation', 'writing', 'web-design', 'coding', 'logo-design', 'trending'],
