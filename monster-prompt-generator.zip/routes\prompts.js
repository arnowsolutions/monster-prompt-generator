const express = require('express');
const Prompt = require('../models/Prompt');
const { auth } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/prompts
// @desc    Get all prompts for authenticated user
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const { category, search, page = 1, limit = 10 } = req.query;
    
    let query = { user: req.user._id };
    
    if (category) {
      query.category = category;
    }
    
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { content: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search, 'i')] } }
      ];
    }

    const prompts = await Prompt.find(query)
      .sort({ updatedAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Prompt.countDocuments(query);

    res.json({
      success: true,
      prompts,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get prompts error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   GET /api/prompts/:id
// @desc    Get single prompt
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const prompt = await Prompt.findOne({ _id: req.params.id, user: req.user._id });
    
    if (!prompt) {
      return res.status(404).json({ error: 'Prompt not found' });
    }

    res.json({ success: true, prompt });
  } catch (error) {
    console.error('Get prompt error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   POST /api/prompts
// @desc    Create new prompt
// @access  Private
router.post('/', auth, async (req, res) => {
  try {
    const prompt = new Prompt({
      ...req.body,
      user: req.user._id
    });

    await prompt.save();
    res.status(201).json({ success: true, prompt });
  } catch (error) {
    console.error('Create prompt error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   PUT /api/prompts/:id
// @desc    Update prompt
// @access  Private
router.put('/:id', auth, async (req, res) => {
  try {
    const prompt = await Prompt.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { ...req.body, updatedAt: Date.now() },
      { new: true, runValidators: true }
    );

    if (!prompt) {
      return res.status(404).json({ error: 'Prompt not found' });
    }

    res.json({ success: true, prompt });
  } catch (error) {
    console.error('Update prompt error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   DELETE /api/prompts/:id
// @desc    Delete prompt
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const prompt = await Prompt.findOneAndDelete({ 
      _id: req.params.id, 
      user: req.user._id 
    });

    if (!prompt) {
      return res.status(404).json({ error: 'Prompt not found' });
    }

    res.json({ success: true, message: 'Prompt deleted successfully' });
  } catch (error) {
    console.error('Delete prompt error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   POST /api/prompts/:id/favorite
// @desc    Toggle favorite status
// @access  Private
router.post('/:id/favorite', auth, async (req, res) => {
  try {
    const prompt = await Prompt.findOne({ _id: req.params.id, user: req.user._id });
    
    if (!prompt) {
      return res.status(404).json({ error: 'Prompt not found' });
    }

    prompt.isFavorite = !prompt.isFavorite;
    await prompt.save();

    res.json({ success: true, prompt });
  } catch (error) {
    console.error('Toggle favorite error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;