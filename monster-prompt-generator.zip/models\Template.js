const mongoose = require('mongoose');

const TemplateSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Template name is required'],
    trim: true,
    maxlength: [100, 'Template name cannot exceed 100 characters']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot exceed 500 characters']
  },
  category: {
    type: String,
    enum: ['image-generation', 'writing', 'web-design', 'coding', 'logo-design', 'trending'],
    required: [true, 'Template category is required']
  },
  structure: {
    type: mongoose.Schema.Types.Mixed,
    required: [true, 'Template structure is required']
  },
  variables: [{
    name: {
      type: String,
      required: true
    },
    type: {
      type: String,
      enum: ['text', 'number', 'select', 'multiselect', 'boolean'],
      required: true
    },
    label: String,
    placeholder: String,
    options: [String],
    required: {
      type: Boolean,
      default: false
    },
    defaultValue: mongoose.Schema.Types.Mixed
  }],
  tags: [String],
  isPublic: {
    type: Boolean,
    default: false
  },
  isFavorite: {
    type: Boolean,
    default: false
  },
  usageCount: {
    type: Number,
    default: 0
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field on save
TemplateSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Index for searching
TemplateSchema.index({ name: 'text', description: 'text', tags: 'text' });

module.exports = mongoose.model('Template', TemplateSchema);