// Export/Import Module for Monster Prompt Generator
// Handles exporting and importing user preferences, templates, and favorites

class ExportImportManager {
    constructor() {
        this.storageKey = 'monsterPromptGenerator_userPreferences';
        this.fileVersion = '1.0.0'; // For future compatibility checks
        this.init();
    }

    // Initialize the export/import manager
    init() {
        this.setupEventListeners();
    }

    // Setup event listeners for export/import buttons
    setupEventListeners() {
        // Export button
        const exportBtn = document.getElementById('export-data-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportUserData();
            });
        }

        // Import button
        const importBtn = document.getElementById('import-data-btn');
        if (importBtn) {
            importBtn.addEventListener('click', () => {
                this.triggerImportDialog();
            });
        }

        // Import file input change
        const importFileInput = document.getElementById('import-file-input');
        if (importFileInput) {
            importFileInput.addEventListener('change', (e) => {
                this.handleImportFile(e.target.files[0]);
            });
        }
    }

    // Export user data to JSON file
    exportUserData() {
        try {
            // Get user preferences from localStorage
            const userPreferences = localStorage.getItem(this.storageKey);
            
            if (!userPreferences) {
                this.showNotification('No data to export', 'error');
                return;
            }

            // Parse the preferences
            const preferences = JSON.parse(userPreferences);
            
            // Create export object with metadata
            const exportData = {
                version: this.fileVersion,
                timestamp: new Date().toISOString(),
                data: preferences
            };

            // Convert to JSON string
            const jsonString = JSON.stringify(exportData, null, 2);
            
            // Create a blob and download link
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            // Create download link and trigger download
            const downloadLink = document.createElement('a');
            downloadLink.href = url;
            downloadLink.download = `monster-prompt-generator-backup-${this.formatDateForFilename(new Date())}.json`;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            
            // Clean up
            document.body.removeChild(downloadLink);
            URL.revokeObjectURL(url);
            
            this.showNotification('Data exported successfully', 'success');
        } catch (error) {
            console.error('Error exporting data:', error);
            this.showNotification('Failed to export data', 'error');
        }
    }

    // Trigger the file input dialog for importing
    triggerImportDialog() {
        const importFileInput = document.getElementById('import-file-input');
        if (importFileInput) {
            importFileInput.click();
        }
    }

    // Handle the imported file
    handleImportFile(file) {
        if (!file) {
            return;
        }

        // Check file type
        if (file.type !== 'application/json') {
            this.showNotification('Please select a JSON file', 'error');
            return;
        }

        const reader = new FileReader();
        
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                this.validateAndImportData(importedData);
            } catch (error) {
                console.error('Error parsing import file:', error);
                this.showNotification('Invalid JSON file', 'error');
            }
        };
        
        reader.onerror = () => {
            this.showNotification('Error reading file', 'error');
        };
        
        reader.readAsText(file);
    }

    // Validate and import the data
    validateAndImportData(importedData) {
        // Basic validation
        if (!importedData || !importedData.data) {
            this.showNotification('Invalid data format', 'error');
            return;
        }

        // Version check for future compatibility
        if (importedData.version && this.compareVersions(importedData.version, this.fileVersion) > 0) {
            if (!confirm('This data was exported from a newer version. Some features may not work correctly. Continue anyway?')) {
                return;
            }
        }

        try {
            // Validate data structure
            this.validateDataStructure(importedData.data);
            
            // Merge or replace existing data
            this.confirmImport(importedData.data);
        } catch (error) {
            console.error('Validation error:', error);
            this.showNotification(`Import failed: ${error.message}`, 'error');
        }
    }

    // Validate the data structure
    validateDataStructure(data) {
        // Check for required properties
        const requiredProperties = ['theme', 'layout', 'favorites', 'customTemplates', 'defaultSettings'];
        
        for (const prop of requiredProperties) {
            if (!data.hasOwnProperty(prop)) {
                throw new Error(`Missing required property: ${prop}`);
            }
        }
        
        // Validate favorites array
        if (!Array.isArray(data.favorites)) {
            throw new Error('Favorites must be an array');
        }
        
        // Validate customTemplates array
        if (!Array.isArray(data.customTemplates)) {
            throw new Error('Custom templates must be an array');
        }
        
        // Validate defaultSettings object
        if (typeof data.defaultSettings !== 'object') {
            throw new Error('Default settings must be an object');
        }
        
        // Additional validation for favorites items
        for (const fav of data.favorites) {
            if (!fav.id || !fav.prompt || !fav.timestamp || !fav.category) {
                throw new Error('Invalid favorite item structure');
            }
        }
        
        // Additional validation for custom templates
        for (const template of data.customTemplates) {
            if (!template.id || !template.name || !template.category || !template.data || !template.timestamp) {
                throw new Error('Invalid template structure');
            }
        }
        
        return true;
    }

    // Confirm import with user and perform the import
    confirmImport(data) {
        const confirmMessage = 'Do you want to replace your current settings with the imported data? ' +
                              'Click "OK" to replace all data or "Cancel" to merge with existing data.';
        
        const shouldReplace = confirm(confirmMessage);
        
        if (shouldReplace) {
            // Replace all data
            localStorage.setItem(this.storageKey, JSON.stringify(data));
            this.showNotification('Data imported successfully (replaced all data)', 'success');
        } else {
            // Merge with existing data
            this.mergeImportedData(data);
            this.showNotification('Data imported successfully (merged with existing data)', 'success');
        }
        
        // Reload the page to apply changes
        if (confirm('Reload page to apply changes?')) {
            window.location.reload();
        }
    }

    // Merge imported data with existing data
    mergeImportedData(importedData) {
        try {
            // Get current data
            const currentDataStr = localStorage.getItem(this.storageKey);
            let currentData = currentDataStr ? JSON.parse(currentDataStr) : {
                theme: 'light',
                layout: 'default',
                favorites: [],
                customTemplates: [],
                defaultSettings: {}
            };
            
            // Merge favorites (avoiding duplicates by ID)
            const existingFavIds = new Set(currentData.favorites.map(fav => fav.id));
            for (const fav of importedData.favorites) {
                if (!existingFavIds.has(fav.id)) {
                    currentData.favorites.push(fav);
                }
            }
            
            // Merge templates (avoiding duplicates by ID)
            const existingTemplateIds = new Set(currentData.customTemplates.map(t => t.id));
            for (const template of importedData.customTemplates) {
                if (!existingTemplateIds.has(template.id)) {
                    currentData.customTemplates.push(template);
                }
            }
            
            // Merge defaultSettings (category by category)
            for (const [category, settings] of Object.entries(importedData.defaultSettings)) {
                if (Object.keys(settings).length > 0) {
                    currentData.defaultSettings[category] = settings;
                }
            }
            
            // Save merged data
            localStorage.setItem(this.storageKey, JSON.stringify(currentData));
        } catch (error) {
            console.error('Error merging data:', error);
            this.showNotification('Error merging data', 'error');
        }
    }

    // Compare version strings (returns -1, 0, or 1)
    compareVersions(v1, v2) {
        const parts1 = v1.split('.').map(Number);
        const parts2 = v2.split('.').map(Number);
        
        for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
            const part1 = parts1[i] || 0;
            const part2 = parts2[i] || 0;
            
            if (part1 < part2) return -1;
            if (part1 > part2) return 1;
        }
        
        return 0;
    }

    // Format date for filename (YYYY-MM-DD)
    formatDateForFilename(date) {
        return date.toISOString().split('T')[0];
    }

    // Show notification
    showNotification(message, type = 'info') {
        if (window.showNotification) {
            window.showNotification(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
            alert(`${message}`);
        }
    }
}

// Initialize export/import manager
let exportImportManager;

document.addEventListener('DOMContentLoaded', function() {
    exportImportManager = new ExportImportManager();
});

// Export for external use
window.ExportImportManager = ExportImportManager;
window.exportImportManager = () => exportImportManager;