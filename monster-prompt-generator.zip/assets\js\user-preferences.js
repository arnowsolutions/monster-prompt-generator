// User Preferences Module for Monster Prompt Generator
// Handles user customization features including themes, favorites, and custom templates

class UserPreferencesManager {
    constructor() {
        this.storageKey = 'monsterPromptGenerator_userPreferences';
        this.preferences = {
            theme: 'light', // light or dark
            layout: 'default', // default, compact, expanded
            favorites: [], // array of saved prompts
            customTemplates: [], // array of user-created templates
            defaultSettings: {
                'image-generation': {},
                'writing': {},
                'web-design': {},
                'coding': {},
                'logo-design': {},
                'trending': {}
            }
        };
        this.init();
    }

    // Initialize preferences
    init() {
        this.loadPreferences();
        this.setupEventListeners();
        this.applyCurrentTheme();
    }

    // Load preferences from localStorage
    loadPreferences() {
        try {
            const saved = localStorage.getItem(this.storageKey);
            if (saved) {
                this.preferences = JSON.parse(saved);
            }
        } catch (error) {
            console.warn('Failed to load user preferences:', error);
        }
    }

    // Save preferences to localStorage
    savePreferences() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.preferences));
        } catch (error) {
            console.warn('Failed to save user preferences:', error);
        }
    }

    // Setup event listeners
    setupEventListeners() {
        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.toggleTheme();
            });
        }

        // Layout options
        const layoutOptions = document.querySelectorAll('[name="layout-option"]');
        layoutOptions.forEach(option => {
            option.addEventListener('change', (e) => {
                this.setLayout(e.target.value);
            });
        });

        // Favorite button
        document.addEventListener('click', (e) => {
            if (e.target.closest('.favorite-btn')) {
                const promptContainer = e.target.closest('.prompt-container');
                if (promptContainer) {
                    const promptId = promptContainer.dataset.promptId;
                    const promptText = promptContainer.querySelector('.prompt-text').textContent;
                    this.toggleFavorite(promptId, promptText);
                }
            }
        });

        // Save template button
        const saveTemplateBtn = document.getElementById('save-template-btn');
        if (saveTemplateBtn) {
            saveTemplateBtn.addEventListener('click', () => {
                this.saveCurrentAsTemplate();
            });
        }
    }

    // Toggle between light and dark theme
    toggleTheme() {
        const newTheme = this.preferences.theme === 'light' ? 'dark' : 'light';
        this.setTheme(newTheme);
    }

    // Set theme
    setTheme(theme) {
        this.preferences.theme = theme;
        this.applyCurrentTheme();
        this.savePreferences();
    }

    // Apply current theme to document
    applyCurrentTheme() {
        if (this.preferences.theme === 'dark') {
            document.documentElement.classList.add('dark-theme');
            document.documentElement.classList.remove('light-theme');
        } else {
            document.documentElement.classList.add('light-theme');
            document.documentElement.classList.remove('dark-theme');
        }

        // Update theme toggle button if it exists
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            const isDark = this.preferences.theme === 'dark';
            themeToggle.innerHTML = isDark ? '☀️' : '🌙';
            themeToggle.setAttribute('title', isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode');
        }
    }

    // Set layout option
    setLayout(layout) {
        this.preferences.layout = layout;
        this.applyCurrentLayout();
        this.savePreferences();
    }

    // Apply current layout
    applyCurrentLayout() {
        const mainContainer = document.querySelector('main');
        if (!mainContainer) return;

        // Remove existing layout classes
        mainContainer.classList.remove('layout-default', 'layout-compact', 'layout-expanded');
        
        // Add current layout class
        mainContainer.classList.add(`layout-${this.preferences.layout}`);
    }

    // Toggle favorite status of a prompt
    toggleFavorite(promptId, promptText) {
        const existingIndex = this.preferences.favorites.findIndex(fav => fav.id === promptId);
        
        if (existingIndex >= 0) {
            // Remove from favorites
            this.preferences.favorites.splice(existingIndex, 1);
            this.showNotification('Removed from favorites', 'info');
        } else {
            // Add to favorites
            this.preferences.favorites.push({
                id: promptId || Date.now().toString(),
                prompt: promptText,
                timestamp: new Date().toISOString(),
                category: this.getCurrentTab()
            });
            this.showNotification('Added to favorites', 'success');
        }
        
        this.savePreferences();
        this.updateFavoritesUI();
    }

    // Update favorites UI
    updateFavoritesUI() {
        const favoritesContainer = document.getElementById('favorites-container');
        if (!favoritesContainer) return;

        if (this.preferences.favorites.length === 0) {
            favoritesContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No favorites yet</p>';
            return;
        }

        favoritesContainer.innerHTML = this.preferences.favorites.map(fav => `
            <div class="favorite-item bg-white rounded-lg shadow-sm p-4 mb-3 border border-gray-200">
                <div class="flex justify-between items-start mb-2">
                    <span class="text-sm font-medium text-blue-600">${this.formatCategory(fav.category)}</span>
                    <span class="text-xs text-gray-500">${this.formatDate(fav.timestamp)}</span>
                </div>
                <p class="text-sm text-gray-700 mb-3">${this.truncateText(fav.prompt, 100)}</p>
                <div class="flex justify-end gap-2">
                    <button class="use-favorite-btn px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                            data-prompt-id="${fav.id}">
                        Use
                    </button>
                    <button class="remove-favorite-btn px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors"
                            data-prompt-id="${fav.id}">
                        Remove
                    </button>
                </div>
            </div>
        `).join('');

        // Add event listeners to the new buttons
        favoritesContainer.querySelectorAll('.use-favorite-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const promptId = e.target.dataset.promptId;
                this.useFavoritePrompt(promptId);
            });
        });

        favoritesContainer.querySelectorAll('.remove-favorite-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const promptId = e.target.dataset.promptId;
                this.removeFavorite(promptId);
            });
        });
    }

    // Use a favorite prompt
    useFavoritePrompt(promptId) {
        const favorite = this.preferences.favorites.find(fav => fav.id === promptId);
        if (!favorite) return;

        // Switch to the appropriate tab
        if (window.MonsterPromptTabs && favorite.category) {
            window.MonsterPromptTabs.switchTab(favorite.category);
        }

        // Import the prompt
        if (window.promptGenerator) {
            window.promptGenerator.importPrompt(favorite.prompt);
            this.showNotification('Favorite prompt loaded', 'success');
        }
    }

    // Remove a favorite
    removeFavorite(promptId) {
        const index = this.preferences.favorites.findIndex(fav => fav.id === promptId);
        if (index >= 0) {
            this.preferences.favorites.splice(index, 1);
            this.savePreferences();
            this.updateFavoritesUI();
            this.showNotification('Removed from favorites', 'info');
        }
    }

    // Save current form as template
    saveCurrentAsTemplate() {
        const templateNameInput = document.getElementById('template-name');
        if (!templateNameInput || !templateNameInput.value.trim()) {
            this.showNotification('Please enter a template name', 'error');
            return;
        }

        const templateName = templateNameInput.value.trim();
        const currentTab = this.getCurrentTab();
        
        // Get current form data
        let templateData = {};
        
        if (window.promptGenerator && window.promptGenerator.getFormData) {
            templateData = window.promptGenerator.getFormData();
        } else {
            // Fallback to manual collection
            templateData = this.collectFormData(currentTab);
        }

        // Create template object
        const template = {
            id: Date.now().toString(),
            name: templateName,
            category: currentTab,
            data: templateData,
            timestamp: new Date().toISOString()
        };

        // Add to templates
        this.preferences.customTemplates.push(template);
        this.savePreferences();
        this.updateTemplatesUI();
        
        // Clear input
        templateNameInput.value = '';
        
        this.showNotification('Template saved successfully', 'success');
    }

    // Collect form data manually
    collectFormData(tabId) {
        const formData = {};
        const form = document.getElementById(tabId);
        if (!form) return formData;

        // Collect input values
        form.querySelectorAll('input, select, textarea').forEach(input => {
            if (input.name) {
                formData[input.name] = input.value;
            } else if (input.id) {
                formData[input.id] = input.value;
            }
        });

        // Collect multi-select buttons
        const multiSelectContainers = form.querySelectorAll('.multi-select-container');
        multiSelectContainers.forEach(container => {
            const containerId = container.id;
            if (containerId) {
                formData[containerId] = Array.from(container.querySelectorAll('.multi-select-btn.selected'))
                    .map(btn => btn.dataset.value);
            }
        });

        return formData;
    }

    // Update templates UI
    updateTemplatesUI() {
        const templatesContainer = document.getElementById('templates-container');
        if (!templatesContainer) return;

        if (this.preferences.customTemplates.length === 0) {
            templatesContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No custom templates yet</p>';
            return;
        }

        templatesContainer.innerHTML = this.preferences.customTemplates.map(template => `
            <div class="template-item bg-white rounded-lg shadow-sm p-4 mb-3 border border-gray-200">
                <div class="flex justify-between items-start mb-2">
                    <span class="text-sm font-medium text-blue-600">${template.name}</span>
                    <span class="text-xs text-gray-500">${this.formatCategory(template.category)}</span>
                </div>
                <p class="text-xs text-gray-500 mb-3">${this.formatDate(template.timestamp)}</p>
                <div class="flex justify-end gap-2">
                    <button class="use-template-btn px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                            data-template-id="${template.id}">
                        Use
                    </button>
                    <button class="remove-template-btn px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors"
                            data-template-id="${template.id}">
                        Remove
                    </button>
                </div>
            </div>
        `).join('');

        // Add event listeners to the new buttons
        templatesContainer.querySelectorAll('.use-template-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const templateId = e.target.dataset.templateId;
                this.useTemplate(templateId);
            });
        });

        templatesContainer.querySelectorAll('.remove-template-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const templateId = e.target.dataset.templateId;
                this.removeTemplate(templateId);
            });
        });
    }

    // Use a template
    useTemplate(templateId) {
        const template = this.preferences.customTemplates.find(t => t.id === templateId);
        if (!template) return;

        // Switch to the appropriate tab
        if (window.MonsterPromptTabs && template.category) {
            window.MonsterPromptTabs.switchTab(template.category);
        }

        // Apply template data to form
        this.applyTemplateToForm(template);
        this.showNotification('Template applied', 'success');
    }

    // Apply template data to form
    applyTemplateToForm(template) {
        const form = document.getElementById(template.category);
        if (!form) return;

        const data = template.data;
        
        // Apply to inputs, selects, and textareas
        for (const [key, value] of Object.entries(data)) {
            const element = document.getElementById(key);
            if (!element) continue;

            if (element.tagName === 'INPUT' || element.tagName === 'SELECT' || element.tagName === 'TEXTAREA') {
                element.value = value;
                
                // Trigger change event
                const event = new Event('change', { bubbles: true });
                element.dispatchEvent(event);
            }
        }

        // Apply to multi-select buttons
        const multiSelectContainers = form.querySelectorAll('.multi-select-container');
        multiSelectContainers.forEach(container => {
            const containerId = container.id;
            if (containerId && data[containerId]) {
                const selectedValues = data[containerId];
                
                // Reset all buttons
                container.querySelectorAll('.multi-select-btn').forEach(btn => {
                    btn.classList.remove('selected');
                });
                
                // Select buttons based on template
                selectedValues.forEach(value => {
                    const btn = container.querySelector(`.multi-select-btn[data-value="${value}"]`);
                    if (btn) {
                        btn.classList.add('selected');
                    }
                });
            }
        });
    }

    // Remove a template
    removeTemplate(templateId) {
        const index = this.preferences.customTemplates.findIndex(t => t.id === templateId);
        if (index >= 0) {
            this.preferences.customTemplates.splice(index, 1);
            this.savePreferences();
            this.updateTemplatesUI();
            this.showNotification('Template removed', 'info');
        }
    }

    // Save default settings for current category
    saveDefaultSettings() {
        const currentTab = this.getCurrentTab();
        
        // Get current form data
        let settingsData = {};
        
        if (window.promptGenerator && window.promptGenerator.getFormData) {
            settingsData = window.promptGenerator.getFormData();
        } else {
            // Fallback to manual collection
            settingsData = this.collectFormData(currentTab);
        }

        // Save as default for this category
        this.preferences.defaultSettings[currentTab] = settingsData;
        this.savePreferences();
        
        this.showNotification('Default settings saved for ' + this.formatCategory(currentTab), 'success');
    }

    // Apply default settings for current category
    applyDefaultSettings() {
        const currentTab = this.getCurrentTab();
        const defaultSettings = this.preferences.defaultSettings[currentTab];
        
        if (!defaultSettings || Object.keys(defaultSettings).length === 0) {
            this.showNotification('No default settings saved for this category', 'info');
            return;
        }

        // Create a template-like object to use the same application method
        const template = {
            category: currentTab,
            data: defaultSettings
        };

        this.applyTemplateToForm(template);
        this.showNotification('Default settings applied', 'success');
    }

    // Get current active tab
    getCurrentTab() {
        const activeTab = document.querySelector('.tab-content.active');
        return activeTab ? activeTab.id : 'image-generation';
    }

    // Format category name for display
    formatCategory(category) {
        if (!category) return 'Unknown';
        
        const categoryMap = {
            'image-generation': 'Image Generation',
            'writing': 'Writing',
            'web-design': 'Web Design',
            'coding': 'Coding',
            'logo-design': 'Logo Design',
            'trending': 'Trending'
        };
        
        return categoryMap[category] || category;
    }

    // Format date for display
    formatDate(dateString) {
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString(undefined, { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
        } catch (error) {
            return 'Unknown date';
        }
    }

    // Truncate text with ellipsis
    truncateText(text, maxLength) {
        if (!text) return '';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }

    // Show notification
    showNotification(message, type = 'info') {
        if (window.showNotification) {
            window.showNotification(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }
}

// Initialize user preferences manager
let userPreferencesManager;

document.addEventListener('DOMContentLoaded', function() {
    userPreferencesManager = new UserPreferencesManager();
});

// Export for external use
window.UserPreferencesManager = UserPreferencesManager;
window.userPreferencesManager = () => userPreferencesManager;