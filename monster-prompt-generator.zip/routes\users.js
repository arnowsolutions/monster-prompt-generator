const express = require('express');
const User = require('../models/User');
const { auth } = require('../middleware/auth');
const { generateToken } = require('../utils/jwt');

const router = express.Router();

// @route   GET /api/users/profile
// @desc    Get user profile
// @access  Private
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    res.json({ success: true, user });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   PUT /api/users/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', auth, async (req, res) => {
  try {
    const { username, email } = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { username, email },
      { new: true, runValidators: true }
    ).select('-password');

    res.json({ success: true, user });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   POST /api/users/api-key
// @desc    Generate new API key
// @access  Private
router.post('/api-key', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    user.apiKey = user.generateApiKey();
    await user.save();
    
    res.json({ success: true, apiKey: user.apiKey });
  } catch (error) {
    console.error('Generate API key error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   DELETE /api/users/api-key
// @desc    Revoke API key
// @access  Private
router.delete('/api-key', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    user.apiKey = null;
    await user.save();
    
    res.json({ success: true, message: 'API key revoked' });
  } catch (error) {
    console.error('Revoke API key error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// @route   PUT /api/users/password
// @desc    Change password
// @access  Private
router.put('/password', auth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    const user = await User.findById(req.user._id);
    const isMatch = await user.comparePassword(currentPassword);
    
    if (!isMatch) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }
    
    user.password = newPassword;
    await user.save();
    
    res.json({ success: true, message: 'Password updated successfully' });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;